#include "globals.h"

int kmerLength = 25;
